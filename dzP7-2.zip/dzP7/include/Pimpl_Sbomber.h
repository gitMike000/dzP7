#ifndef PIMPL_SBOMBER_H
#define PIMPL_SBOMBER_H

class SBomber;

class Pimpl_Sbomber {
public:

    Pimpl_Sbomber();
    ~Pimpl_Sbomber();

    bool GetExitFlag() const;
    void ProcessKBHit();
    void TimeStart();
    void TimeFinish();

    void DrawFrame();
    void MoveObjects();
    void CheckObjects();

//private:

    SBomber* sb;

};

#endif // PIMPL_SBOMBER_H
