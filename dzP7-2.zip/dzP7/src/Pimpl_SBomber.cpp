#include "include/SBomber.h"
#include "include/Pimpl_Sbomber.h"

Pimpl_Sbomber::Pimpl_Sbomber(): sb (new SBomber()) {};
Pimpl_Sbomber::~Pimpl_Sbomber() {delete sb;sb=0;};

bool Pimpl_Sbomber::GetExitFlag() const {return sb->GetExitFlag();};

void Pimpl_Sbomber::ProcessKBHit() {sb->ProcessKBHit();};

void Pimpl_Sbomber::TimeStart() {sb->TimeStart();};
void Pimpl_Sbomber::TimeFinish() {sb->TimeFinish();};

void Pimpl_Sbomber::DrawFrame() {sb->DrawFrame();};
void Pimpl_Sbomber::MoveObjects() {sb->MoveObjects();};
void Pimpl_Sbomber::CheckObjects() {sb->CheckObjects();};
