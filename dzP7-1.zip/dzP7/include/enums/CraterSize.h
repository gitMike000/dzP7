//#pragma once
#ifndef CraterSize_H
#define CraterSize_H

enum CraterSize { SMALL_CRATER_SIZE = 9 };

#endif //CraterSize_H
