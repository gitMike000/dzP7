//#pragma once

#ifndef MYTOOLS_H
#define MYTOOLS_H

#include <string>
#include <cstring>

#include <fstream>
#include <iostream>

namespace MyTools {

class FileLogger {

public:
    FileLogger() {
        OpenLogFile("log.txt");
    };

    ~FileLogger() {
        CloseLogFile();
    };

    void OpenLogFile(const std::string& FN);

    void CloseLogFile();

    void WriteToLog(const std::string& str);

    void WriteToLog(const std::string& str, int n);

    void WriteToLog(const std::string& str, double d);

private:
    std::ofstream logOut;
};

static FileLogger logger;

}; // namespace MyTools

#endif //MYTOOLS_H
